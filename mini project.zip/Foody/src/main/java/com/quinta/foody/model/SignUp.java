package com.quinta.foody.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="signup_tbl")
public class SignUp {
	
	@Id
	@Column(name="email_id",length=20)
	private String emailId;
	
	
	@Column(name="full_name",length=20)
	private String fullName;
	
	
	
	
	@Column(name="password",length=20)
	private String password;

	public SignUp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SignUp(String fullName, String emailId, String password) {
		super();
		this.fullName = fullName;
		this.emailId = emailId;
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SignUp [fullName=" + fullName + ", emailId=" + emailId + ", password=" + password + "]";
	}
	

}	
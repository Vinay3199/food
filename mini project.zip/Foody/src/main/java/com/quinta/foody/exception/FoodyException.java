package com.quinta.foody.exception;


public class FoodyException extends Exception
{

  public FoodyException(String message)
  {
   super(message);
  }

  public FoodyException()
  {
   super();
  }
}